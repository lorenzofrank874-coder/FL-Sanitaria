FL SANITARIA - PROYECTO ANDROID

Este es un proyecto Android Studio tipo WebView para empaquetar la app local.

Pasos:
1. Abrir la carpeta android en Android Studio.
2. Esperar sincronización de Gradle.
3. Build > Build APK(s).
4. Instalar el APK generado en app/build/outputs/apk/debug/app-debug.apk.

No se incluye APK compilado: esta entrega contiene el proyecto fuente. Se necesita Android Studio/SDK para compilarlo.
